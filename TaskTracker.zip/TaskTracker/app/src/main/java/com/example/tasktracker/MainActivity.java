package com.example.tasktracker;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import androidx.appcompat.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.widget.DatePicker;
import android.graphics.Color;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
Button add;
AlertDialog dialog;
LinearLayout layout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        add = findViewById(R.id.add);
        layout = findViewById(R.id.container);

        buildDialog();
        add.setOnClickListener(new View.OnClickListener(){
        @Override
        public void onClick (View v){
            dialog.show();
        }
    });
    }
    public void buildDialog(){
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        View view=getLayoutInflater().inflate(R.layout.dialog,null);

        final EditText name = view.findViewById(R.id.nameEdit);
        final DatePicker date= view.findViewById(R.id.datePicker);
        final Calendar calendar = Calendar.getInstance();
        date.init(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH), new DatePicker.OnDateChangedListener() {
            @Override
            public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                calendar.set(year, monthOfYear, dayOfMonth);
            }
        });
        builder.setView(view);
        builder.setTitle("Enter your Task")
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        addCard(name.getText().toString(),calendar);
                    }
                })
                .setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
        dialog= builder.create();
    }
    private void addCard(String name, Calendar calendar){
        final View view = getLayoutInflater().inflate(R.layout.card,null);

        TextView nameView = view.findViewById(R.id.name);
        TextView dateView = view.findViewById(R.id.date);

        Button delete = view.findViewById(R.id.delete);
        nameView.setText(name);
        dateView.setText(new SimpleDateFormat("MMMM dd, yyyy", Locale.getDefault()).format(calendar.getTime()));

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layout.removeView(view);
            }
        });
        Calendar currentDate = Calendar.getInstance();

        // Compare the date shown in the card view with the current date
        if (calendar.get(Calendar.YEAR) == currentDate.get(Calendar.YEAR) &&
                calendar.get(Calendar.MONTH) == currentDate.get(Calendar.MONTH) &&
                calendar.get(Calendar.DAY_OF_MONTH) == currentDate.get(Calendar.DAY_OF_MONTH)) {
            // If they are the same, set the background color of the layout to red
            dateView.setTextColor(Color.RED);
            nameView.setTextColor(Color.RED);
        } else if (calendar.get(Calendar.YEAR) == currentDate.get(Calendar.YEAR) &&
                calendar.get(Calendar.MONTH) == currentDate.get(Calendar.MONTH) &&
                calendar.get(Calendar.DAY_OF_MONTH)-2 == currentDate.get(Calendar.DAY_OF_MONTH)) {
            float[] hsv = {12, 100, 100};
            dateView.setTextColor(Color.HSVToColor(hsv));
            nameView.setTextColor(Color.HSVToColor(hsv));
        }
        else {
            dateView.setTextColor(Color.GREEN);
            nameView.setTextColor(Color.GREEN);
        }
        layout.addView(view);



    }
}