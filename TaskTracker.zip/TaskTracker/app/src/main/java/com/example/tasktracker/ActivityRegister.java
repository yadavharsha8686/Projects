package com.example.tasktracker;

import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class ActivityRegister extends AppCompatActivity {
    EditText etUser,etpwd,etRepwd;
    Button btnRegister,btnLogin;
    DataBaseHelper dataBaseHelper;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        etUser = findViewById(R.id.etUsername);
        etpwd = findViewById(R.id.etPassword);
        etRepwd= findViewById(R.id.etRePassword);
        btnRegister=findViewById(R.id.btnRegister);
        btnLogin=findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ActivityRegister.this,ActivityLogin.class);
                startActivity(intent);
            }
        });
        dataBaseHelper= new DataBaseHelper(this);
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user, pwd,rePwd;
                user=etUser.getText().toString();
                pwd= etpwd.getText().toString();
                rePwd=etRepwd.getText().toString();
                if(user.equals("")|| pwd.equals("") || rePwd.equals("")){
                    Toast.makeText(ActivityRegister.this,"Please Fill All the fields",Toast.LENGTH_LONG).show();
                }
                else {
                    if (pwd.equals(rePwd)){
                        if (dataBaseHelper.checkUsername(user)){
                            Toast.makeText(ActivityRegister.this,"User Already Exists",Toast.LENGTH_LONG).show();
                        }
                    boolean registeredSuccess =    dataBaseHelper.insertData(user,pwd);
                    if(registeredSuccess)
                        Toast.makeText(ActivityRegister.this,"Successfully Registered",Toast.LENGTH_LONG).show();
                    else  Toast.makeText(ActivityRegister.this,"Registration Failed",Toast.LENGTH_LONG).show();
                    }
                    else {
                        Toast.makeText(ActivityRegister.this,"Passwords doesn't Match",Toast.LENGTH_LONG).show();
                    }
                }
            }
        });

    }
}
