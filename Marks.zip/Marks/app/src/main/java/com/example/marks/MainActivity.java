package com.example.marks;

import androidx.appcompat.app.AppCompatActivity;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    DatabaseHelper myDb;

    EditText editName, editMarks, editId;
    Button btnAddData;
    Button btnViewAll;
    Button btnUpdate;
    Button btnDelete;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myDb = new DatabaseHelper(this);

        editName = findViewById(R.id.editText_name);
        editMarks = findViewById(R.id.editText_marks);
        editId = findViewById(R.id.editText_id);

        btnAddData = findViewById(R.id.button_add);
        btnViewAll = findViewById(R.id.button_viewAll);
        btnUpdate = findViewById(R.id.button_update);
        btnDelete = findViewById(R.id.button_delete);

        btnDelete.setOnClickListener(v -> {
            Integer deletedRows = myDb.deleteData(editId.getText().toString());
            if (deletedRows > 0) {
                Log.d("tag"," record deleted");
            } else {
                Log.d("tag","no record deleted");
            }
        });

        btnUpdate.setOnClickListener(v -> {
            boolean isUpdated = myDb.updateData(editId.getText().toString(),
                    editName.getText().toString(),
                    editMarks.getText().toString());
            if (isUpdated) {
                Log.d("tag","  record updated");
            } else {
                Log.d("tag"," no records updated");
            }

        });

        btnAddData.setOnClickListener(v -> {
            boolean isInserted = myDb.insertData(editName.getText().toString(),
                    editMarks.getText().toString());
            if (isInserted) {
                Log.d("tag"," record added");
            } else {
                Log.d("tag","no record added");
            }
        });

        btnViewAll.setOnClickListener(v -> {
            Cursor res = myDb.getAllData();
            if (res.getCount() == 0) {
                Log.d("tag","no records found");
            } else {
                while (res.moveToNext()) {
                    Log.d(TAG, "id: " + res.getString(0) + ", name: " + res.getString(1) + ", marks: " + res.getString(2)+ "   All Data records");
                }

                StringBuffer buffer = new StringBuffer();
                buffer.append("Record Data...\n");
                while (res.moveToNext()) { //cycle thru result set
                    buffer.append("Id :" + res.getString(0) + "\n");
                    buffer.append("Name :" + res.getString(1) + "\n");
                    buffer.append("Marks :" + res.getString(2) + "\n\n");
                }
                // Show all data
                Log.i("Data", buffer.toString());

            }
        });
    }
}